from Controller.TicTacToeService import TicTacToeService
from Repository.TicTacToeRepository import TicTacToeRepository


class Tests:
    """
    Clasa pentru testele aplicatiei
    """

    def __init__(self):
        """
        Constructorul clasei Tests
        """
        #self.__repository = TicTacToeRepository()
        #self.__service = TicTacToeService(self.__repository)


    def runTests(self):
        """
        Functia ruleaza testele propriu-zise ale clasei
        :return:
        """



