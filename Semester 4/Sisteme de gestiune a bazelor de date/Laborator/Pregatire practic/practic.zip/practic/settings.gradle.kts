rootProject.name = "practic"
