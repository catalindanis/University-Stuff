export function encrypt(pass){
    let result='';
    for (let i=0;i<pass.length;i++) {
        result += String.fromCharCode(pass.charCodeAt(i)+3);
    }
    return result
}