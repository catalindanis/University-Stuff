package chat.services;

import chat.model.Message;
import chat.model.User;


public interface IChatClient {
    public void messageReceived(Message message) throws ChatException;
    public void userLoggedIn(User friend) throws ChatException;
    public void userLoggedOut(User friend) throws ChatException;
}
