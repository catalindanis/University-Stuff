package chat.services;

import chat.model.Message;
import chat.model.User;


public interface IChatServer {
    void login(User user, IChatClient client) throws ChatException;
    void sendMessage(Message message) throws ChatException;
    void sendMessageToAll(Message message) throws ChatException;
    void logout(User user, IChatClient client) throws ChatException;
    User[] getLoggedUsers() throws ChatException;
}
