
import React, {useEffect, useState} from 'react';
import MessagesService from '../services/MessagesService.js';
import LogoutComponent from "./LogoutComponent.jsx";


function MessageRow({message}){
    return (
        <tr>
            <td>{message.from}</td>
            <td>{message.message}</td>
        </tr>
    );
}

const SendMessage = ({errorMessageFunc}) => {
    const [data, setData] = useState({
        to: "",
        message: ""
    });

    const handleChange = (e) => {
        const value = e.target.value;
        setData({
            ...data,
            [e.target.name]: value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const message = {
            from:localStorage.getItem('username'),
            to: data.to,
            message: data.message
        };
        MessagesService.saveMessage(message).then(response=>{console.log(response)}).catch((error)=>{
            console.log("eroare"+error)
            errorMessageFunc("Eroare trimitere mesaj "+error.message)});
    };

    return (
        <div>
            <h1>Send message</h1>
            <form onSubmit={handleSubmit}>
                <label htmlFor="to">
                    To
                    <input
                        type="text"
                        name="to"
                        value={data.to}
                        onChange={handleChange}
                        required
                    />
                </label>
                <label htmlFor="message">
                    Message
                    <input
                        type="text"
                        name="message"
                        value={data.message}
                        onChange={handleChange}
                        required
                    />
                </label>
                <button type="submit" className="btn btn-primary">Send message</button>
            </form>
        </div>
    );
};

const MessagesComponent = () => {
   const [messages, setMessages]=useState([])
    const [testMessage, setTestMessage]=useState('Test Message')
    const [errorMessage, setErrorMessage] = useState('');

    useEffect( () => {
        MessagesService.getTestMessage().then(response=>setTestMessage(response.data)).catch(error=>{
            console.log("eroare apel public "+error)
            setErrorMessage("Eroare apel public "+error.message)});

        MessagesService.getMessagesTo(localStorage.getItem('username')).
       then(response=>{
           console.log(response)
           setMessages(response.data)}).
        catch((error)=>{
            console.log("eroare"+error)
            setErrorMessage("Eroare afisare mesaje "+error.message)});

    }, []);
   let rows=[]
    let counter=0;
   messages.forEach(function(message){
       rows.push(<MessageRow message={message} key={counter++}/>)
   })
    return (

        <div>
            {errorMessage && <div className="alert alert-danger">{errorMessage}</div>}
            <h3 color="blue">Apel public {testMessage}</h3>
            <h1>Messages for {localStorage.getItem('username')} </h1>
            <table className="MessageTable">
                <thead>
                <tr>
                    <th>From</th>
                    <th>Text</th>
                </tr>
                </thead>
                <tbody>{rows}</tbody>
            </table>
            <SendMessage errorMessageFunc={setErrorMessage}/>
            <LogoutComponent/>
        </div>
    );
};

export default MessagesComponent;