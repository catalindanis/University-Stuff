import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const LogoutComponent = () => {
    const navigate = useNavigate();

    const handleLogout = async (e) => {
        e.preventDefault();
        localStorage.removeItem('token')
        localStorage.removeItem('username')
        navigate('/login');
    };
    return (
        <div className="container mt-5">
            <button  className="btn btn-primary" onClick={handleLogout}>Logout</button>
        </div>
    );
};

export default LogoutComponent;