import axios from 'axios';

const API_BASE_URL = "http://localhost:8080/api/messages";

class MessageService {
    getMessagesTo(username) {
        console.log(username)
        const instance = axios.create({
            baseURL: `${API_BASE_URL}`,
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,

            }
        });
        return instance.get(`${API_BASE_URL}?to=${username}`);
    }


    getTestMessage(){
        return axios.get(`${API_BASE_URL}/test`);
    }

    saveMessage(message){
        console.log(message)
        const instance = axios.create({
            baseURL: `${API_BASE_URL}`,
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,

            }
        });
        return instance.post(`${API_BASE_URL}`, message);


    }
}
export default new MessageService();