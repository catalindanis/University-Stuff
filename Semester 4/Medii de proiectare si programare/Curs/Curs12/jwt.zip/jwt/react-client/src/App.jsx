import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginComponent from './components/LoginComponent.jsx';
import MessagesComponent from './components/MessagesComponent.jsx';

const App = () => {
    return (
        <Router>
            <div className="container">
                <Routes>
                    <Route path="/" element={<LoginComponent />} />
                    <Route path="/login" element={<LoginComponent />} />
                    <Route path="/messages" element={<MessagesComponent />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;
