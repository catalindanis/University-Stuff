package ro.mpp.jwt.service;

import ro.mpp.jwt.model.User;

public interface UserService {
    User findByUsername(String username);
    User saveUser(User user);
}
