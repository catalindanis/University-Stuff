package ro.mpp.jwt.repository;

import ro.mpp.jwt.model.Message;

import java.util.List;

public interface MessageRepository {
    List<Message> getMessages(String to);
    Message save(Message message);
}
