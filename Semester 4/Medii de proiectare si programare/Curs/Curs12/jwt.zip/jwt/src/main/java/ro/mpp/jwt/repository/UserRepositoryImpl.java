package ro.mpp.jwt.repository;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;
import ro.mpp.jwt.model.User;

import java.util.HashMap;
import java.util.Map;

@Repository
public class UserRepositoryImpl implements UserRepository{
    private Map<String, User> users;


    private PasswordEncoder passwordEncoder;

    public UserRepositoryImpl(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
        users = new HashMap<>();
        users.put("ana", new User("ana",passwordEncoder.encode("ana"),"user"));
        users.put("test", new User("test",passwordEncoder.encode("test"),"user"));
        users.put("ion", new User("ion",passwordEncoder.encode("ion"),"admin"));
        printUsers();
    }

    private void printUsers() {
        System.out.println(users);
    }
    @Override
    public User findByUsername(String username) {
        return users.get(username);
    }

    @Override
    public User save(User user) {
        if (users.containsKey(user.getUsername())) {
            return users.get(user.getUsername());
        }
        users.put(user.getUsername(), user);
        return user;
    }
}
