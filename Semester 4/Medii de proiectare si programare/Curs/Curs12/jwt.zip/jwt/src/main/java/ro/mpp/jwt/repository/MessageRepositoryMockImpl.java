package ro.mpp.jwt.repository;


import org.springframework.stereotype.Repository;
import ro.mpp.jwt.model.Message;

import java.util.ArrayList;
import java.util.List;

@Repository
public class MessageRepositoryMockImpl implements  MessageRepository{
    private List<Message> messages;
    public MessageRepositoryMockImpl(){
        messages=new ArrayList<>();
        messages.add(new Message("Hello", "ana", "ion"));
        messages.add(new Message("Halo", "ion", "ana"));
        messages.add(new Message("Salut", "test", "ana"));
        messages.add(new Message("Hola", "ana", "test"));
    }
    public List<Message> getMessages(String to) {
        return messages.stream().filter(m->m.getTo().equalsIgnoreCase(to)).toList();
    }
    public Message save(Message message){
        messages.add(message);
        return message;
    }


}
