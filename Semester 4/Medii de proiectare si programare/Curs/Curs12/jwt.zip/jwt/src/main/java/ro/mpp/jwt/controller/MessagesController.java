package ro.mpp.jwt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.context.MessageSourceAutoConfiguration;
import org.springframework.web.bind.annotation.*;
import ro.mpp.jwt.model.Message;
import ro.mpp.jwt.repository.MessageRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Locale;

@RestController
@RequestMapping("api/messages")
public class MessagesController {

    @Autowired
    MessageRepository messageRepository;


    @GetMapping("test")
    public String greeting(){
        System.out.println("MessageController in greeting" );
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss dd/MM/yyyy");
        return "Hello at " + LocalDateTime.now().format(formatter);
    }


    @GetMapping
    public List<Message> getMessages(@RequestParam(required = true, name="to") String to) {
        System.out.println("In getMessages to " +to );
        System.out.println("Result "+messageRepository.getMessages(to));
        return messageRepository.getMessages(to);
    }
    @PostMapping
    public Message saveMessage(@RequestBody Message message) {
        System.out.println("In saveMessage "+message );
        return messageRepository.save(message);
    }
}
