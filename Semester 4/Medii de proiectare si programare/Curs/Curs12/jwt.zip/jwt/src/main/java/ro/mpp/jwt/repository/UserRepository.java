package ro.mpp.jwt.repository;


import ro.mpp.jwt.model.User;


public interface UserRepository  {
    User findByUsername(String username);
    User save(User user);
}
