package chat.services.notification;

import chat.model.User;
import chat.services.websockets.ChatWebsocketHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.List;

@Component
public class ChatWebSocketNotification implements ChatNotificationService{

    @Autowired
    private ChatWebsocketHandler webSocketHandler;

    public ChatWebSocketNotification(){
        System.out.println("creating ChatWebSocketNotification");
    }
    @Override
    public void usersUpdated(User[] users) {
        webSocketHandler.sendUsersAll(users);
    }
}
