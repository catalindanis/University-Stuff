package chat.services.notification;

import chat.model.User;

import java.util.List;

public interface ChatNotificationService {
    public void usersUpdated(User[] users);
}
